import { config } from 'dotenv';
config();

import '@/ai/flows/venture-summary-with-ai-insights.ts';